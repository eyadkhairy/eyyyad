"use client";
import React from "react";

function MainComponent() {
  return (
    <div>
      <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
      />

      <div className="portfolio-container">
        {/* Navigation */}
        <nav className="navbar">
          <div className="nav-container">
            <div className="nav-logo">Eyad Khairy</div>
            <ul className="nav-menu">
              <li>
                <a href="#home" className="nav-link">
                  Home
                </a>
              </li>
              <li>
                <a href="#about" className="nav-link">
                  About
                </a>
              </li>
              <li>
                <a href="#portfolio" className="nav-link">
                  Portfolio
                </a>
              </li>
              <li>
                <a href="#contact" className="nav-link">
                  Contact
                </a>
              </li>
            </ul>
          </div>
        </nav>

        {/* Animated Background */}
        <div className="bg-animation">
          <div className="floating-element element-1"></div>
          <div className="floating-element element-2"></div>
          <div className="floating-element element-3"></div>
          <div className="floating-element element-4"></div>
          <div className="floating-element element-5"></div>
        </div>

        {/* Hero Section */}
        <section id="home" className="hero-section">
          <div className="hero-content">
            <div className="profile-photo">
              <img
                src="https://i.postimg.cc/G8vKzb06/IMG-20250729-012538-121.jpg"
                alt="Eyad Khairy - Video Editor and Visual Storyteller"
              />
            </div>
            <h1 className="hero-title">Eyad Khairy</h1>
            <p className="hero-subtitle">Video Editor & Visual Storyteller</p>
            <p className="hero-info">
              18 years old • 2+ Years Experience • Based in Egypt
            </p>
            <div className="hero-buttons">
              <a href="#portfolio" className="btn btn-primary">
                View My Work
              </a>
              <a href="#contact" className="btn btn-secondary">
                Get In Touch
              </a>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="about-section">
          <div className="container">
            <h2 className="section-title">About Me</h2>
            <div className="about-content">
              <div className="about-text">
                <p>
                  I'm a passionate and skilled video editor based in Egypt, with
                  over 2 years of experience in the industry. Despite being just
                  18 years old, I've already worked with top companies and built
                  a strong portfolio.
                </p>
                <ul className="about-features">
                  <li>
                    <i className="fas fa-check"></i> Proven Industry Experience
                    – Worked with Dtag and Omedia
                  </li>
                  <li>
                    <i className="fas fa-check"></i> Leadership & Teamwork –
                    Founder and leader of Youth Media
                  </li>
                  <li>
                    <i className="fas fa-check"></i> Adobe Suite Proficiency –
                    Premiere Pro & After Effects
                  </li>
                  <li>
                    <i className="fas fa-check"></i> Adaptability & Creativity –
                    Always eager to learn and innovate
                  </li>
                </ul>
                <div className="note">
                  <p>
                    <strong>Note:</strong> As part of my religion, I do not
                    incorporate music into my edits. However, I'm adept at using
                    alternative audio elements (e.g., ambient sounds,
                    voiceovers, and SFX) to maintain energy and impact.
                  </p>
                </div>
              </div>
              <div className="skills-container">
                <h3>Skills & Expertise</h3>
                <div className="skill">
                  <span>Adobe Premiere Pro</span>
                  <div className="skill-bar">
                    <div className="skill-progress" data-width="95"></div>
                  </div>
                  <span className="skill-percent">95%</span>
                </div>
                <div className="skill">
                  <span>Adobe After Effects</span>
                  <div className="skill-bar">
                    <div className="skill-progress" data-width="90"></div>
                  </div>
                  <span className="skill-percent">90%</span>
                </div>
                <div className="skill">
                  <span>Visual Storytelling</span>
                  <div className="skill-bar">
                    <div className="skill-progress" data-width="95"></div>
                  </div>
                  <span className="skill-percent">95%</span>
                </div>
                <div className="skill">
                  <span>Color Grading</span>
                  <div className="skill-bar">
                    <div className="skill-progress" data-width="85"></div>
                  </div>
                  <span className="skill-percent">85%</span>
                </div>
                <div className="skill">
                  <span>Motion Graphics</span>
                  <div className="skill-bar">
                    <div className="skill-progress" data-width="80"></div>
                  </div>
                  <span className="skill-percent">80%</span>
                </div>
                <div className="skill">
                  <span>Team Leadership</span>
                  <div className="skill-bar">
                    <div className="skill-progress" data-width="90"></div>
                  </div>
                  <span className="skill-percent">90%</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Portfolio Section */}
        <section id="portfolio" className="portfolio-section">
          <div className="container">
            <h2 className="section-title">My Portfolio</h2>
            <div className="portfolio-grid">
              <div
                className="portfolio-card"
                data-url="https://youtu.be/UgHkxsK5aLI?si=xwvRAyyMykv1ckrb"
              >
                <div className="card-overlay">
                  <i className="fas fa-play-circle"></i>
                </div>
                <div className="card-content">
                  <span className="card-category">Event Coverage</span>
                  <h3>Wild Wheels Event</h3>
                  <p>
                    Dynamic automotive event coverage with cinematic transitions
                    and professional editing
                  </p>
                </div>
              </div>
              <div
                className="portfolio-card"
                data-url="https://youtu.be/IyND0Df5Fis?si=aIm9HqGVeffQuBaw"
              >
                <div className="card-overlay">
                  <i className="fas fa-play-circle"></i>
                </div>
                <div className="card-content">
                  <span className="card-category">Documentary</span>
                  <h3>Charity Work</h3>
                  <p>
                    Heartwarming charity event documentation with emotional
                    storytelling
                  </p>
                </div>
              </div>
              <div
                className="portfolio-card"
                data-url="https://youtu.be/CB_b_xqD6Mg?si=qxX02cMpf-9qCvWx"
              >
                <div className="card-overlay">
                  <i className="fas fa-play-circle"></i>
                </div>
                <div className="card-content">
                  <span className="card-category">Cinematic</span>
                  <h3>Cinematic Style</h3>
                  <p>
                    High-end cinematic production showcasing advanced visual
                    techniques
                  </p>
                </div>
              </div>
              <div
                className="portfolio-card"
                data-url="https://youtu.be/MadX23f6mGM?si=1mmNQ-T5pypDy5KB"
              >
                <div className="card-overlay">
                  <i className="fas fa-play-circle"></i>
                </div>
                <div className="card-content">
                  <span className="card-category">Commercial</span>
                  <h3>Food Advertisement</h3>
                  <p>
                    Appetizing food commercial with mouth-watering visuals and
                    smooth transitions
                  </p>
                </div>
              </div>
              <div
                className="portfolio-card"
                data-url="https://youtube.com/shorts/q2Xy5oA6TWQ?si=qtQAxIr5T__ZhQ30"
              >
                <div className="card-overlay">
                  <i className="fas fa-play-circle"></i>
                </div>
                <div className="card-content">
                  <span className="card-category">Social Media</span>
                  <h3>Auto Moka</h3>
                  <p>
                    Creative automotive content with engaging visual
                    storytelling
                  </p>
                </div>
              </div>
              <div
                className="portfolio-card"
                data-url="https://youtube.com/shorts/JXlghF6ONJo?si=7do1CuYF2z2w3vuj"
              >
                <div className="card-overlay">
                  <i className="fas fa-play-circle"></i>
                </div>
                <div className="card-content">
                  <span className="card-category">Fitness</span>
                  <h3>Core</h3>
                  <p>
                    Dynamic gym and fitness content with energetic editing and
                    motivational flow
                  </p>
                </div>
              </div>
              <div
                className="portfolio-card"
                data-url="https://youtube.com/shorts/Ij5Jw4LOw6Y?si=M1X51_U1ltJWPqdb"
              >
                <div className="card-overlay">
                  <i className="fas fa-play-circle"></i>
                </div>
                <div className="card-content">
                  <span className="card-category">Social Media</span>
                  <h3>Auto Moka 2</h3>
                  <p>
                    Continued automotive series with consistent branding and
                    visual excellence
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="contact-section">
          <div className="container">
            <h2 className="section-title">Let's Work Together</h2>
            <p className="contact-intro">
              Driven by a passion for visual storytelling, I'm committed to
              creating content that stands out. Let's bring your vision to life!
            </p>
            <div className="contact-grid">
              <a href="mailto:eydookhairy@gmail.com" className="contact-card">
                <i className="fas fa-envelope"></i>
                <h3>Email</h3>
                <p>eydookhairy@gmail.com</p>
              </a>
              <a href="tel:+2001004567328" className="contact-card">
                <i className="fas fa-phone"></i>
                <h3>Phone</h3>
                <p>+20 010 0456 7328</p>
              </a>
              <a
                href="https://www.instagram.com/khairy_ve?igsh=aXMzZW9kajIzMDgx"
                target="_blank"
                rel="noopener noreferrer"
                className="contact-card"
              >
                <i className="fab fa-instagram"></i>
                <h3>Instagram</h3>
                <p>@khairy_ve</p>
              </a>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="footer">
          <p>
            © 2025 Eyad Khairy. All rights reserved. • Video Editor & Visual
            Storyteller
          </p>
        </footer>
      </div>

      <style jsx global>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        html {
          scroll-behavior: smooth;
        }

        body {
          font-family: 'Arial', sans-serif;
          background: #000;
          color: #fff;
          overflow-x: hidden;
        }

        .portfolio-container {
          position: relative;
          min-height: 100vh;
        }

        /* Navigation */
        .navbar {
          position: fixed;
          top: 0;
          width: 100%;
          background: rgba(0, 0, 0, 0.9);
          backdrop-filter: blur(10px);
          z-index: 1000;
          padding: 1rem 0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .nav-container {
          max-width: 1200px;
          margin: 0 auto;
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 0 2rem;
        }

        .nav-logo {
          font-size: 1.5rem;
          font-weight: bold;
          background: linear-gradient(45deg, #8b5cf6, #ec4899);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .nav-menu {
          display: flex;
          list-style: none;
          gap: 2rem;
        }

        .nav-link {
          color: #fff;
          text-decoration: none;
          transition: color 0.3s ease;
        }

        .nav-link:hover {
          color: #8b5cf6;
        }

        /* Animated Background */
        .bg-animation {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: -1;
          background: linear-gradient(135deg, #1a1a2e, #16213e, #0f3460);
        }

        .floating-element {
          position: absolute;
          border-radius: 50%;
          opacity: 0.1;
          animation: float 6s ease-in-out infinite;
        }

        .element-1 {
          width: 300px;
          height: 300px;
          background: linear-gradient(45deg, #8b5cf6, #ec4899);
          top: 10%;
          left: 10%;
          animation-delay: 0s;
        }

        .element-2 {
          width: 200px;
          height: 200px;
          background: linear-gradient(45deg, #3b82f6, #8b5cf6);
          top: 60%;
          right: 10%;
          animation-delay: 2s;
        }

        .element-3 {
          width: 150px;
          height: 150px;
          background: linear-gradient(45deg, #ec4899, #f59e0b);
          bottom: 20%;
          left: 20%;
          animation-delay: 4s;
        }

        .element-4 {
          width: 100px;
          height: 100px;
          background: linear-gradient(45deg, #10b981, #3b82f6);
          top: 30%;
          right: 30%;
          animation-delay: 1s;
        }

        .element-5 {
          width: 250px;
          height: 250px;
          background: linear-gradient(45deg, #f59e0b, #ef4444);
          bottom: 10%;
          right: 20%;
          animation-delay: 3s;
        }

        @keyframes float {
          0%, 100% {
            transform: translateY(0px) rotate(0deg);
          }
          50% {
            transform: translateY(-20px) rotate(180deg);
          }
        }

        /* Hero Section */
        .hero-section {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          text-align: center;
          padding: 0 2rem;
        }

        .hero-content {
          max-width: 800px;
          animation: fadeInUp 1s ease-out;
        }

        .profile-photo {
          margin-bottom: 2rem;
          animation: pulse 2s infinite;
        }

        .profile-photo img {
          width: 150px;
          height: 150px;
          border-radius: 50%;
          border: 4px solid #8b5cf6;
          box-shadow: 0 0 30px rgba(139, 92, 246, 0.5);
        }

        .hero-title {
          font-size: 4rem;
          font-weight: bold;
          margin-bottom: 1rem;
          background: linear-gradient(45deg, #8b5cf6, #ec4899, #3b82f6);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: glow 2s ease-in-out infinite alternate;
        }

        .hero-subtitle {
          font-size: 1.5rem;
          margin-bottom: 1rem;
          color: #d1d5db;
        }

        .hero-info {
          font-size: 1.1rem;
          margin-bottom: 2rem;
          color: #9ca3af;
        }

        .hero-buttons {
          display: flex;
          gap: 1rem;
          justify-content: center;
          flex-wrap: wrap;
        }

        .btn {
          padding: 1rem 2rem;
          border-radius: 50px;
          text-decoration: none;
          font-weight: bold;
          transition: all 0.3s ease;
          display: inline-block;
        }

        .btn-primary {
          background: linear-gradient(45deg, #8b5cf6, #ec4899);
          color: white;
          box-shadow: 0 4px 15px rgba(139, 92, 246, 0.4);
        }

        .btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 25px rgba(139, 92, 246, 0.6);
        }

        .btn-secondary {
          border: 2px solid #8b5cf6;
          color: #8b5cf6;
          background: transparent;
        }

        .btn-secondary:hover {
          background: #8b5cf6;
          color: white;
          transform: translateY(-2px);
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes pulse {
          0%, 100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.05);
          }
        }

        @keyframes glow {
          from {
            text-shadow: 0 0 20px rgba(139, 92, 246, 0.5);
          }
          to {
            text-shadow: 0 0 30px rgba(139, 92, 246, 0.8);
          }
        }

        /* Sections */
        .container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 2rem;
        }

        .section-title {
          font-size: 3rem;
          text-align: center;
          margin-bottom: 3rem;
          background: linear-gradient(45deg, #8b5cf6, #ec4899);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        /* About Section */
        .about-section {
          padding: 5rem 0;
        }

        .about-content {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 3rem;
          align-items: start;
        }

        .about-text p {
          font-size: 1.1rem;
          line-height: 1.8;
          margin-bottom: 2rem;
          color: #d1d5db;
        }

        .about-features {
          list-style: none;
          margin-bottom: 2rem;
        }

        .about-features li {
          display: flex;
          align-items: center;
          margin-bottom: 1rem;
          color: #d1d5db;
        }

        .about-features i {
          color: #8b5cf6;
          margin-right: 1rem;
        }

        .note {
          background: rgba(139, 92, 246, 0.1);
          border: 1px solid rgba(139, 92, 246, 0.3);
          border-radius: 10px;
          padding: 1.5rem;
        }

        .note p {
          font-size: 0.9rem;
          color: #d1d5db;
          margin: 0;
        }

        .skills-container {
          background: rgba(255, 255, 255, 0.05);
          border-radius: 15px;
          padding: 2rem;
          border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .skills-container h3 {
          text-align: center;
          margin-bottom: 2rem;
          background: linear-gradient(45deg, #8b5cf6, #ec4899);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .skill {
          margin-bottom: 1.5rem;
        }

        .skill span:first-child {
          display: block;
          margin-bottom: 0.5rem;
          color: #d1d5db;
        }

        .skill-bar {
          background: rgba(255, 255, 255, 0.1);
          height: 8px;
          border-radius: 4px;
          overflow: hidden;
          margin-bottom: 0.5rem;
        }

        .skill-progress {
          height: 100%;
          background: linear-gradient(45deg, #8b5cf6, #ec4899);
          border-radius: 4px;
          width: 0;
          animation: fillBar 2s ease-out forwards;
          animation-delay: 0.5s;
        }

        .skill-percent {
          color: #8b5cf6;
          font-weight: bold;
        }

        @keyframes fillBar {
          to {
            width: var(--width);
          }
        }

        /* Portfolio Section */
        .portfolio-section {
          padding: 5rem 0;
        }

        .portfolio-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
          gap: 2rem;
        }

        .portfolio-card {
          background: rgba(255, 255, 255, 0.05);
          border-radius: 15px;
          overflow: hidden;
          border: 1px solid rgba(255, 255, 255, 0.1);
          transition: all 0.3s ease;
          cursor: pointer;
          position: relative;
        }

        .portfolio-card:hover {
          transform: translateY(-10px);
          border-color: #8b5cf6;
          box-shadow: 0 20px 40px rgba(139, 92, 246, 0.3);
        }

        .card-overlay {
          height: 200px;
          background: linear-gradient(135deg, rgba(139, 92, 246, 0.3), rgba(236, 72, 153, 0.3));
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 3rem;
          color: #8b5cf6;
          transition: all 0.3s ease;
        }

        .portfolio-card:hover .card-overlay {
          background: linear-gradient(135deg, rgba(139, 92, 246, 0.6), rgba(236, 72, 153, 0.6));
        }

        .card-content {
          padding: 1.5rem;
        }

        .card-category {
          background: rgba(139, 92, 246, 0.3);
          color: #8b5cf6;
          padding: 0.3rem 0.8rem;
          border-radius: 20px;
          font-size: 0.8rem;
          display: inline-block;
          margin-bottom: 1rem;
        }

        .card-content h3 {
          margin-bottom: 1rem;
          color: #fff;
        }

        .card-content p {
          color: #9ca3af;
          line-height: 1.6;
        }

        /* Contact Section */
        .contact-section {
          padding: 5rem 0;
        }

        .contact-intro {
          text-align: center;
          font-size: 1.2rem;
          margin-bottom: 3rem;
          color: #d1d5db;
          max-width: 600px;
          margin-left: auto;
          margin-right: auto;
        }

        .contact-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 2rem;
        }

        .contact-card {
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 15px;
          padding: 2rem;
          text-align: center;
          text-decoration: none;
          color: inherit;
          transition: all 0.3s ease;
        }

        .contact-card:hover {
          transform: translateY(-5px);
          border-color: #8b5cf6;
          box-shadow: 0 15px 30px rgba(139, 92, 246, 0.3);
        }

        .contact-card i {
          font-size: 2.5rem;
          margin-bottom: 1rem;
          color: #8b5cf6;
        }

        .contact-card h3 {
          margin-bottom: 0.5rem;
          color: #fff;
        }

        .contact-card p {
          color: #9ca3af;
        }

        /* Footer */
        .footer {
          border-top: 1px solid rgba(255, 255, 255, 0.1);
          padding: 2rem 0;
          text-align: center;
          color: #9ca3af;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
          .nav-menu {
            display: none;
          }

          .hero-title {
            font-size: 2.5rem;
          }

          .about-content {
            grid-template-columns: 1fr;
          }

          .portfolio-grid {
            grid-template-columns: 1fr;
          }

          .hero-buttons {
            flex-direction: column;
            align-items: center;
          }

          .btn {
            width: 200px;
          }
        }

        @media (max-width: 480px) {
          .hero-title {
            font-size: 2rem;
          }

          .section-title {
            font-size: 2rem;
          }

          .container {
            padding: 0 1rem;
          }
        }
      `}</style>

      <script>{`
        document.addEventListener('DOMContentLoaded', function() {
          // Smooth scroll for navigation links
          const navLinks = document.querySelectorAll('.nav-link');
          navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
              e.preventDefault();
              const targetId = this.getAttribute('href');
              const targetSection = document.querySelector(targetId);
              if (targetSection) {
                targetSection.scrollIntoView({
                  behavior: 'smooth'
                });
              }
            });
          });

          // Portfolio card click handlers
          const portfolioCards = document.querySelectorAll('.portfolio-card');
          portfolioCards.forEach(card => {
            card.addEventListener('click', function() {
              const url = this.getAttribute('data-url');
              if (url) {
                window.open(url, '_blank');
              }
            });
          });

          // Animate skill bars when they come into view
          const skillBars = document.querySelectorAll('.skill-progress');
          const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
              if (entry.isIntersecting) {
                const width = entry.target.getAttribute('data-width');
                entry.target.style.setProperty('--width', width + '%');
              }
            });
          });

          skillBars.forEach(bar => {
            observer.observe(bar);
          });

          // Add scroll effect to navbar
          window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 100) {
              navbar.style.background = 'rgba(0, 0, 0, 0.95)';
            } else {
              navbar.style.background = 'rgba(0, 0, 0, 0.9)';
            }
          });
        });
      `}</script>
    </div>
  );
}

export default MainComponent;